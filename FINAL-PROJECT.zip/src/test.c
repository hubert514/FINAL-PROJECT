// #include <stdio.h>
// #include <string.h>

// int main(int argc, char const *argv[])
// {
//     char a[1024] = "是這樣的，err...，在混沌紀元以前，整個星球都是我的礦業公會。直到一名自稱龍裔救世主的神秘領袖出現，";

//     printf("strlen(a) = %ld\n", strlen(a));


//     return 0;
// }
